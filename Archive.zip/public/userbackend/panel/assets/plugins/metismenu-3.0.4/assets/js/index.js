$(function() {
  $('table').addClass('table table-bordered table-striped');
});

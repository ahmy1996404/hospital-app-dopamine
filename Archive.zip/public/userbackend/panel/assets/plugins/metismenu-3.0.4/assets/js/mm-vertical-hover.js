$(function() {

  $('#menu1').metisMenu();

});

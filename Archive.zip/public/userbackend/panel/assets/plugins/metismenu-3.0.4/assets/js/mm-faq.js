$(function() {

  $('.faq-menu').metisMenu({
    toggle: false,
    triggerElement: '.faq-link',
    parentTrigger: '.faq-item',
    subMenu: '.faq-answer'
  });

});
